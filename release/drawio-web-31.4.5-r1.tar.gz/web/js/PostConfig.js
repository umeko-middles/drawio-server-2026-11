/**
 * Copyright (c) 2006-2024, JGraph Holdings Ltd
 * Copyright (c) 2006-2024, draw.io AG
 */
// null'ing of global vars need to be after init.js
window.ICONSEARCH_PATH = null;
window.ICON_SERVICE_PATH = null;

// doc-master offline deployment overrides (drawio-server-2026-11).
window.EXPORT_URL = null;
window.VSS_CONVERT_URL = null;
window.ICONSEARCH_PATH = null;
window.ICON_SERVICE_PATH = null;
